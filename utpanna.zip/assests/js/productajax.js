$(document).ready(function () {
	
	function filter() {
		var category= $("#category").val();
		var locationFilter=$("#locationFilter").val();
		$.ajax({
			type: "POST",
			data: {
				category: category,
				locationFilter: locationFilter
			},
			url: "./controller/productCtrl.php",
			success: function (response) {
				console.log(category);
				console.log(locationFilter);
				let productsArr = JSON.parse(response);
				console.log(productsArr);
				let htmlString = ``;
				productsArr.forEach((product) => {
					htmlString += `
					<div class="col-md-3 each-product-outside">
						<div class="each-product-inside">
							<div class="each-product-img">
							<a href="product-detail.php?product=${product.id}">	<img src="./img/${product.item_image}" alt=""></a>
							</div>
							<div class="each-product-content">
							<a href="product-detail.php?product=${product.id}"><h2>${product.item_name}</h2></a>
								<h6>${product.size}</h6>
								<div class="row">
									<div class="col-md-4"><h4>${product.price}/-</h4></div>
									<div class="add-to-cart-form">
									<input type="hidden" class="pid" value="${product.id}">
									<input type="hidden" class="pname" value="${product.item_name}">
									<input type="hidden" class="pimage" value="./img/${product.item_image}">
									<input type="hidden" class="pprice" value="${product.price}">
									<input type="hidden" class="psize" value="${product.size}">
									<div class="col-md-8 float-right"><button class="add-to-cart">Add To Cart</button></div>
									</div>
								</div>
							</div>
						</div>
				</div> `;
				});
				$("#allProduct").html(htmlString);
				$(".add-to-cart").click(function(e) {
					
					e.preventDefault();
						var $form = $(this).closest(".add-to-cart-form");
						var pid = $form.find(".pid").val();
						var pname = $form.find(".pname").val();
						var pimage = $form.find(".pimage").val();
						var pprice = $form.find(".pprice").val();
						var psize = $form.find(".psize").val();
						$.ajax({
							type: "POST",
							data: {
								pid: pid,
								pname: pname,
								pimage: pimage,
								pprice: pprice,
								psize: psize,
							},
							url: "./controller/cartCtrl.php",
							success: function (response) {
								console.log(response);
								if (response === "login first") {
									window.location.href =
									"http://farmerspure.com/utpanna-online/login.php?error=Log In to use cart";
								}
								else if(response === "Item Added Successfully")
								$("#cart-message").html(
									'<div class="success-alert alert alert-light text-success"><div class="animation-ctn"><div class="icon icon--order-success svg"><svg xmlns="http://www.w3.org/2000/svg" width="154px" height="154px"><g fill="none" stroke="rgb(3, 153, 3)" stroke-width="2"><circle cx="77" cy="77" r="72" style="stroke-dasharray:480px, 480px; stroke-dashoffset: 960px;"></circle><circle id="colored" fill="rgb(3, 153, 3)" cx="77" cy="77" r="72" style="stroke-dasharray:480px, 480px; stroke-dashoffset: 960px;"></circle><polyline class="st0" stroke="#fff" stroke-width="10" points="43.5,77.8 63.7,97.9 112.2,49.4 " style="stroke-dasharray:100px, 100px; stroke-dashoffset: 200px;"/></g></svg></div></div>' +
										response +
										"</div>"
								)
								else{
									$("#cart-message").html(
										'<div class="success-alert alert alert-light text-danger"><div class="animation-ctn"><div class="icon icon--order-success svg"><svg xmlns="http://www.w3.org/2000/svg" width="154px" height="154px"><g fill="none" stroke="#F44812" stroke-width="2"><circle cx="77" cy="77" r="72" style="stroke-dasharray:480px, 480px; stroke-dashoffset: 960px;"></circle><circle id="colored" fill="#F44812" cx="77" cy="77" r="72" style="stroke-dasharray:480px, 480px; stroke-dashoffset: 960px;"></circle><polyline class="st0" stroke="#fff" stroke-width="10" points="43.5,77.8  112.2,77.8 " style="stroke-dasharray:100px, 100px; stroke-dashoffset: 200px;"/></g></svg></div></div>'+response +
											"</div>"
									)
								}
								$(".success-alert").fadeTo(1200, 300).slideUp(1200, function(){
									$(".success-alert").slideUp(1200);
									location.reload(true);
								});
							},
						});
				});
			},
		});
	}
	function addToCart() {
		var $form = $(".add-to-cart").closest(".add-to-cart-form");
		var pid = $form.find(".pid").val();
		var pname = $form.find(".pname").val();
		var pimage = $form.find(".pimage").val();
		var pprice = $form.find(".pprice").val();
		var psize = $form.find(".psize").val();
		$.ajax({
			type: "POST",
			data: {
				pid: pid,
				pname: pname,
				pimage: pimage,
				pprice: pprice,
				psize: psize,
			},
			url: "./controller/cartCtrl.php",
			success: function (response) {
				if (response === "login first") {
					window.location.href =
					"http://farmerspure.com/utpanna-online/login.php?error=Log In to use cart";
				}
				else if(response === "Item Added Successfully")
				$("#cart-message").html(
					'<div class="success-alert alert alert-light text-success"><div class="animation-ctn"><div class="icon icon--order-success svg"><svg xmlns="http://www.w3.org/2000/svg" width="154px" height="154px"><g fill="none" stroke="rgb(3, 153, 3)" stroke-width="2"><circle cx="77" cy="77" r="72" style="stroke-dasharray:480px, 480px; stroke-dashoffset: 960px;"></circle><circle id="colored" fill="rgb(3, 153, 3)" cx="77" cy="77" r="72" style="stroke-dasharray:480px, 480px; stroke-dashoffset: 960px;"></circle><polyline class="st0" stroke="#fff" stroke-width="10" points="43.5,77.8 63.7,97.9 112.2,49.4 " style="stroke-dasharray:100px, 100px; stroke-dashoffset: 200px;"/></g></svg></div></div>' +
						response +
						"</div>",
				)
				else{
					$("#cart-message").html(
						'<div class="success-alert alert alert-light text-danger"><div class="animation-ctn"><div class="icon icon--order-success svg"><svg xmlns="http://www.w3.org/2000/svg" width="154px" height="154px"><g fill="none" stroke="#F44812" stroke-width="2"><circle cx="77" cy="77" r="72" style="stroke-dasharray:480px, 480px; stroke-dashoffset: 960px;"></circle><circle id="colored" fill="#F44812" cx="77" cy="77" r="72" style="stroke-dasharray:480px, 480px; stroke-dashoffset: 960px;"></circle><polyline class="st0" stroke="#fff" stroke-width="10" points="43.5,77.8  112.2,77.8 " style="stroke-dasharray:100px, 100px; stroke-dashoffset: 200px;"/></g></svg></div></div>' +
							response +
							"</div>",
					)
				}
				$(".success-alert").fadeTo(1200, 300).slideUp(1200, function(){
					$(".success-alert").slideUp(1200);
					location.reload(true);
				});
			},
		});
	}

	// NOTE Filtering using Location

	$("#category").on("change", function () {
		// filter method by default provides 
		filter();
	});


	// NOTE Filtering using Location

	$("#locationFilter").on("change", function () {
		filter();
	});




	$(".pQuantity").change(function (e) {
		e.preventDefault();
		const $tr = $(this).closest("tr");
		const productQuantity = $tr.find(".pQuantity").val();
		const hCartItemId = $tr.find(".hCartItemId").val();
		const hCartUserId = $tr.find(".hCartUserId").val();
		const hCartItemPrice = $tr.find(".hCartItemPrice").val();
		const hCartItemMainPrice = $tr.find(".hCartItemMainPrice").val();

		$.ajax({
			type: "POST",
			url: "./controller/cartCtrl.php",
			data: {
				productQuantity: productQuantity,
				hCartItemId: hCartItemId,
				hCartUserId: hCartUserId,
				hCartItemPrice: hCartItemPrice,
				hCartItemMainPrice: hCartItemMainPrice,
			},
			success: function (response) {
				location.reload(true);
			},
		});
	});
	$(".add-to-cart").click(function (e) {
		e.preventDefault();
		addToCart();
  });
  


  // Check File Name
  if (
	location.href==="http://localhost/Organic-Utpanna/"||
	location.href==="http://localhost/Organic-Utpanna/index.php" ||
	location.href==="http://farmerspure.com/utpanna-online/" ||
	location.href==="http://farmerspure.com/utpanna-online/index.php"||
	location.href==="http://farmerspure.com/utpanna-online/index.php#"
	) {    
  filter();
}




});