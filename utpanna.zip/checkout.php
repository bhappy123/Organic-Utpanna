<?php include('./views/header.php') ?>
<?php
if(!isset($_SESSION['userId'])){
  header("Location: ./login.php?error=Log In To Initiate Order");
}
?>

<!-- Checkout form -->
<div class="check-out">
<div class="login-page">
    <div class="form">
      <div><?php isset($_GET['err']) ? $_GET['err'] : " ";  ?></div>
      <form action="./controller/orderCtrl.php" method="POST"  class="register-form">
        <h3 class="text-center text-danger pb-3">Amount To Be Paid: <span class="text-dark">Rs.<?php echo $_GET['full_payment']  ?></span></h3>
        <input name="c_name"  type="text" placeholder="Name"/>
        <input name="c_phone"  type="tel" placeholder="Phone"/>
        <input name="c_email"  type="email" placeholder="Email address"/>
        <input name="c_address"  type="text" placeholder="Address"/>
        <input name="c_zip"  type="number" placeholder="Zip Code"/>
        <input  type="hidden" name="hUserId" value="<?php echo $_SESSION['userId'] ?>">
        <button name="checkOutBtn">ORDER NOW</button>
      </form>
     
    </div>
  </div>
</div>
<!-- Checkout form -->
<?php include('./views/footer.php') ?>