<?php include('./views/header.php') ?>

    <section class="head-carousel">
        <div class="owl-carousel owl-theme">
          <div class="item"><img src="./assests/img/1.jpg" alt="" /></div>
          <div class="item"><img src="./assests/img/2.jpg" alt="" /></div>
          <div class="item"><img src="./assests/img/1.jpg" alt="" /></div>
          <div class="item"><img src="./assests/img/2.jpg" alt="" /></div>
        </div>
      </section>
      <div id="cart-message"></div>
<!-- Shopping Cards -->
      <div class="container shopping-cards">
        <h3 class="shopping-cards-heading">OUR <span>PRODUCTS</span></h3>
        <div class="row product-filter justify-content-center">
            <div class="col-md-6 col-xs-6">
                <label for="category">Category</label>
                <select class="browser-default custom-select" id="category">
                    <option disabled>Categories </option>
                    <option selected value="all">All</option>
                    <option value="rice">rice</option>
                    <option value="millets">millets</option>
                    <option value="cereals_and_flours">Cereals and Flours</option>
                    <option value="pulses_and_dals">Pulses and Dals</option>
                    <option value="spices_and_masala">Spices and Masala</option>
                    <option value="sweetener">Sweetener</option>
                    <option value="salt">Salt</option>
                    <option value="oils_and_ghee">Oils and Ghee</option>
                    <option value="nuts_and_dry_fruits">Nuts and Dry Fruits</option>
                    <option value="seeds_and_dry_fruits">Seeds And Dry Fruits</option>
                    <option value="herbs">Herbs</option>
                    <option value="personal_care">Personal Care</option>
                    <option value="ready_to_eat">Ready To Eat</option>
                  </select>
            </div>
            <div class="col-xs-6">
            <label for="category">Location</label>
                <select class="browser-default custom-select" id="locationFilter">
                    <option disabled>Choose Your Location </option>
                    <option selected>All</option>
                    <option value="bbsr">Bhubaneswar</option>
                    <option value="cuttack">Cuttack</option>
                    <option value="brahampur">Brahampur</option>
                    <option value="jharsuguda">jharsugurah</option>
                    <option value="sundergarh">Sundergarh</option>
                  </select>
            </div>
        </div>
        <!-- <div class="row" id="allProduct">
            <div class="col-md-3 col-sm-6">
                <div class="product-grid4">
                    <div class="product-image4">
                        <a href="#">
                            <img class="pic-1" src="./assests/img/product1.png">
                        </a>
                        <ul class="social">
                            <li><a href="" data-tip="View"><i class="fa fa-eye"></i></a></li>
                        </ul>
                    </div>
                    <div class="product-content">
                        <h3 class="title"><a href="#">Rice</a></h3>
                        <span class="badge badge-success p-1 mb-1">1kg</span>
                        <div class="price">
                            120.00
                        </div>
                        <form action="" class="add-to-cart-form">
                            <input type="hidden" class="pid" value="<?php ?>">
                            <input type="hidden" class="pname" value="<?php ?>">
                            <input type="hidden" class="pimage" value="<?php ?>">
                            <input type="hidden" class="pprice" value="<?php ?>">
                            <input type="hidden" class="psize" value="<?php ?>">
                            <a class="add-to-cart-btn add-to-cart" href="">ADD TO CART</a>
                        </form>
                    </div>
                </div>
            </div>
        </div> -->

        <section class="product-card-section">
        <div class="container">
            <div class="row product-card-justify" id="allProduct">
                
            </div>
        </div>
    </section>


    </div>

    

<?php include('./views/footer.php'); ?>