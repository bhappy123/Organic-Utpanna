<?php include('./views/header.php')  ?>
<?php include('./controller/orderCtrl.php')  ?>

<div class="previous-orders">
    <h1>My Orders</h1>
<div class="table-responsive" id="sailorTableArea">
    <table id="sailorTable" class="table table-striped table-bordered" width="100%">
 
        <thead>
            <tr>
                <th>Sl.</th>
                <th>Products & Quantity</th>
                <th>Address</th>
                <th>Zip Code</th>
                <th>Price</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($all_user_orders as $order_data) { ?>
                <tr>
                <td>#</td>
                <td><?php echo  $order_data['products']  ?></td>
                <td><?php echo  $order_data['address']  ?></td>
                <td><?php echo  $order_data['zip_code']  ?></td>
                <td><?php echo  $order_data['payment']  ?></td>
                <td><?php echo  $order_data['order_status']  ?></td>
            </tr>
               <?php }  ?>
        </tbody>
    </table>
    </div>
</div>

<?php include('./views/footer.php')  ?>