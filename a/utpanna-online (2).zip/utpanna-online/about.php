<?php include('./views/header.php') ?>


<div class="aboutus-area">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
            <div class="col-md-4 col-sm-6 col-xs-12">    
                <div class="aboutus-image float-left hidden-sm"><img src="./img/about.jpg" alt=""></div>
                </div>
            <div class="col-md-8 col-sm-6 col-xs-12">
                <div class="aboutus-content ">
                    <h1>Organic <span>Utpanna</span></h1>
                    <h4 class="pt-2">Honestly Pure</h4>
                    <p> UTPANNA® which implies produce has a deep rooted belief that a healthy life comes from the Mother Earth. With this philosophy comes a deep reverence and relentlessly we ensure that our products must be qualitatively best and Organic by origin. We ought to respect the protector of our lands and their sustainability.</p>
                    </div>
            </div>    
            </div>
        </div>
    </div>
</div>


<?php include('./views/footer.php') ?>