<?php include('./views/header.php') ?>
<?php
if(!isset($_SESSION['userId'])){
  header("Location: ./login.php?error=Log In To Initiate Order");
}
?>
<?php 
$grand_total = $_GET['grand_total'];
if($_GET['couponApp'] === "yes"){
  $grand_total = ($grand_total * 0.9);
} 
else{
  $grand_total = $_GET['full_payment'];
}
if($grand_total < 500){
  $grand_total += 60;
}
$grand_total = round($grand_total,0);
?>

<!-- Checkout form -->
<div class="check-out">
<div class="login-page">
    <div class="form">
      <div><?php isset($_GET['err']) ? $_GET['err'] : " ";  ?></div>
      <form action="./controller/orderCtrl.php" method="POST"  class="register-form">
        <h3 class="text-center text-danger pb-3">Amount To Be Paid: <span class="text-dark">Rs.<?php echo $grand_total  ?></span></h3>
        <input name="c_name"  type="text" placeholder="Name"/>
        <input name="c_phone"  type="number" placeholder="Phone"/>
        <input name="c_email"  type="email" placeholder="Email address"/>
        <input name="c_address"  type="text" placeholder="Address"/>
        <input name="c_zip"  type="number" placeholder="Zip Code"/>
        <input  type="hidden" name="hUserId" value="<?php echo $_SESSION['userId'] ?>">
        <input  type="hidden" name="hCouponStatus" value="<?php echo $_GET['couponApp'] ?>">
        <button name="checkOutBtn">ORDER NOW</button>
      </form>
    </div>
  </div>
</div>
<!-- Checkout form -->
<?php include('./views/footer.php') ?>