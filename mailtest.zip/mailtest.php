<?php
    require('./PHPMailer/PHPMailerAutoload.php');

    $mail = new PHPMailer();

    $mail->Host = "smtp.gmail.com";

    $mail->isSMTP();

    $mail->SMTPAuth = true;

    $mail->Username = "bikashranjandash0@gmail.com";

    $mail->Password = "bikash123";

    $mail->SMTPSecure = "ssl";

    $mail->Port = 465;

    $mail->Subject = "Test Email";

    $mail->Body ="This is test Body...";

    $mail->setFrom(address: 'bikashranjandash0@gmail.com', name: 'Bikash');

    $mail->addAddress(address: 'bikashranjandash2@gmail.com');

    if($mail->send()){
        echo "mail sent";
    }
    else{
        echo "err";
    }

?>


