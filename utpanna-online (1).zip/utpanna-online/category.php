<?php include('./views/header.php');
      include('./controller/categoryCtrl.php'); ?>


<section class="product-card-section">
        <div class="container">
            <div class="row product-card-justify" id="allProduct">
			<!-- Php Code  -->
			<?php foreach ($products as $product) {  ?>
				<div id="cart-message"></div>
            <div class="col-md-3 each-product-outside">
						<div class="each-product-inside">
							<div class="each-product-img">
							<a href="product-detail.php?product=<?php echo $product['id']  ?>">	<img src="./img/<?php echo $product['item_image'] ?>" alt=""></a>
							</div>
							<div class="each-product-content">
							<a href="product-detail.php?product=<?php echo $product['id']  ?>"><h2><?php echo $product['item_name'] ?></h2></a>
								<h6><?php echo $product['size'] ?></h6>
								<div class="row">
									<div class="col-md-4"><h4><?php echo $product['price'] ?>/-</h4></div>
									<div class="add-to-cart-form">
									<input type="hidden" class="pid" value="<?php echo $product['id'] ?>">
									<input type="hidden" class="pname" value="<?php echo $product['item_name'] ?>">
									<input type="hidden" class="pimage" value="./img/<?php echo $product['item_image'] ?>">
									<input type="hidden" class="pprice" value="<?php echo $product['price'] ?>">
									<input type="hidden" class="psize" value="<?php echo $product['size'] ?>">
									<div class="col-md-8 float-right"><button class="add-to-cart">Add To Cart</button></div>
									</div>
								</div>
							</div>
						</div>
				</div>

				<?php }  ?>
            </div>
        </div>
    </section>



<?php include('./views/footer.php')  ?>