<?php
// $conn = mysqli_connect('localhost', 'root', '', 'organic_utpanna');
$conn = mysqli_connect('localhost', 'justamin_utpanna', 'justamin_utpanna', 'justamin_utpanna');
?>